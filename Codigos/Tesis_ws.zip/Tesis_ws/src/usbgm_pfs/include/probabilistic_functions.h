
#include "../include/global.h"



cv::Mat GetFloorPrior(cv::Mat img, vector<Superpixel> superpixels)
{
	cv::Mat

}